export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { message, peer_id, access_token } = req.body;

  if (!message || !peer_id || !access_token) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  const params = new URLSearchParams({
    message,
    peer_id,
    random_id: Date.now().toString(),
    access_token,
    v: '5.199'
  });

  try {
    const vkRes = await fetch(`https://api.vk.com/method/messages.send?${params.toString()}`);
    const data = await vkRes.json();
    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ error: 'VK API request failed', details: error.toString() });
  }
}
